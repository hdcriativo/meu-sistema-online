import { PendingRegistrations } from "@/components/admin/pending-registrations"

export default function CadastrosPendentesPage() {
  return (
    <div className="p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100 mb-2">Cadastros Pendentes</h1>
          <p className="text-slate-600 dark:text-slate-400">
            Gerencie solicitações de acesso de novos usuários ao sistema
          </p>
        </div>

        <PendingRegistrations />
      </div>
    </div>
  )
}
