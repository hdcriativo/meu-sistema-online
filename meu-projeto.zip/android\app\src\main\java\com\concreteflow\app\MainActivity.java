package com.concreteflow.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
