// ARQUIVO: app/admin/usuarios/page.tsx

"use client";

import { useMemo } from 'react';
import { AppLayout } from '@/components/layout/app-layout';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DataTable } from '@/components/ui/data-table';
import { mockUsers } from '@/lib/mock-data';
import { User } from '@/lib/types';
import { Users, ShieldAlert, PlusCircle } from 'lucide-react';

// --- FUNÇÕES AUXILIARES ---
const roleVariant = (role: string): "default" | "concluido" | "recusado" | "em_andamento" => {
  switch (role) {
    case "admin": return "recusado"; // Usando 'recusado' para vermelho/alerta
    case "vendedor": return "em_andamento"; // Amarelo/Laranja
    case "motorista": return "concluido"; // Verde
    default: return "default";
  }
}

// --- DEFINIÇÃO DAS COLUNAS DA DATATABLE ---
const columns = [
  {
    accessorKey: "name",
    header: "Nome",
  },
  {
    accessorKey: "email",
    header: "Email de Login",
  },
  {
    accessorKey: "role",
    header: "Perfil",
    cell: ({ row }: { row: any }) => (
      <Badge variant={roleVariant(row.original.role as string)}>
        {row.original.role.toUpperCase()}
      </Badge>
    ),
  },
  {
    accessorKey: "id",
    header: "ID",
    cell: ({ row }: { row: any }) => `#${row.original.id.toUpperCase()}`,
  },
];

// --- COMPONENTE PRINCIPAL ---
export default function AdminUsuariosPage() {
  
  // Usamos useMemo para garantir que a DataTable receba o array de usuários
  const usersData = useMemo(() => mockUsers, []);

  // NOTA: Em uma aplicação real, você faria um useEffect/fetch aqui para buscar os dados.
  
  return (
    <AppLayout>
      <div className="p-8 max-w-7xl mx-auto space-y-6">
        
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold flex items-center">
            <ShieldAlert className="h-7 w-7 mr-3 text-red-600" />
            Gestão de Usuários (Admin)
          </h1>
          <Button className="bg-green-600 hover:bg-green-700">
            <PlusCircle className="mr-2 h-4 w-4" /> Novo Usuário
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista Completa de Usuários</CardTitle>
            <CardDescription>
                Esta tela é visível apenas para usuários com o perfil 'admin'.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Aqui usamos a mesma DataTable do módulo de orçamentos */}
            <DataTable 
                columns={columns} 
                data={usersData} 
                filterColumn="name" // Permite pesquisar pelo nome
            />
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}