import {
  Entrega,
  Empresa,
  User,
  Product,
  Agendamento,
  Obra,
  FinanceiroMovimento,
  Usina, // Novo: Importado do definitions
  ConfiguracoesEmpresa, // Novo: Importado do definitions
} from "@/lib/definitions";

// ====================================================================
// DEFINIÇÕES BASE (Inalteradas)
// ====================================================================

export const mockEmpresas: Empresa[] = [
  { id: "1", name: "Empresa A", address: "Rua A, 123", contact: "111-1111" },
  { id: "2", name: "Empresa B", address: "Rua B, 456", contact: "222-2222" },
];

export const mockUsers: User[] = [
  {
    id: "u1",
    name: "Admin User",
    email: "admin@empresa.com",
    password: "password",
    role: "admin",
    empresaId: "1",
  },
  {
    id: "u2",
    name: "Vendedor User",
    email: "vendedor@empresa.com",
    password: "password",
    role: "vendedor",
    empresaId: "1",
  },
  {
    id: "u3",
    name: "Motorista User",
    email: "motorista@empresa.com",
    password: "password",
    role: "motorista",
    empresaId: "1",
  },
  {
    id: "u4",
    name: "Bombista User",
    email: "bombista@empresa.com",
    password: "password",
    role: "bombista",
    empresaId: "1",
  },
  {
    id: "u5",
    name: "Ajudante User",
    email: "ajudante@empresa.com",
    password: "password",
    role: "ajudante",
    empresaId: "1",
  },
  {
    id: "u6",
    name: "Admin Empresa B",
    email: "admin@empresab.com",
    password: "password",
    role: "admin",
    empresaId: "2",
  },
];

// ====================================================================
// MOCK DE ENTREGAS (Atualizado com Viagens, Vendedor e Agendamento)
// ====================================================================

export const mockEntregas: Entrega[] = [
  {
    id: "e1",
    empresaId: "1",
    motoristaId: "u3",
    status: "em rota", // Status ajustado
    dataCriacao: new Date("2024-05-01"),
    produtos: [
      { id: "p1", name: "Produto 1", quantidade: 10 },
      { id: "p2", name: "Produto 2", quantidade: 5 },
    ],
    enderecoEntrega: "Av. Principal, 789",
    agendamentoId: "a2", // Ligado ao agendamento (Entrega urgente)
    vendedorId: "u2", // Vendedor u2 fez a venda
    volumeTotalM3: 15, // Volume esperado
    viagens: [ // Viagens para o motorista registrar
        { id: "v1_e1", volumeM3: 7, status: "concluida", timestamp: new Date("2024-05-01T10:00:00") },
        { id: "v2_e1", volumeM3: 8, status: "em rota", timestamp: new Date("2024-05-01T13:00:00") },
    ],
  },
  {
    id: "e2",
    empresaId: "1",
    motoristaId: "u3",
    status: "entregue",
    dataCriacao: new Date("2024-05-02"),
    produtos: [{ id: "p3", name: "Produto 3", quantidade: 2 }],
    enderecoEntrega: "Rua das Flores, 101",
    agendamentoId: "a3", // Novo agendamento de exemplo
    vendedorId: "u2", // Vendedor u2 fez a venda
    volumeTotalM3: 10,
    viagens: [
        { id: "v1_e2", volumeM3: 10, status: "concluida", timestamp: new Date("2024-05-02T14:30:00") },
    ],
  },
  {
    id: "e3",
    empresaId: "1",
    motoristaId: "u4", // Motorista diferente (Bombista, apenas exemplo)
    status: "entregue",
    dataCriacao: new Date("2024-05-03"),
    produtos: [
      { id: "p4", name: "Produto 4", quantidade: 3 },
      { id: "p5", name: "Produto 5", quantidade: 8 },
    ],
    enderecoEntrega: "Travessa do Sol, 202",
    agendamentoId: "a4", // Novo agendamento de exemplo
    vendedorId: "u5", // Vendedor u5 (Ajudante, apenas exemplo)
    volumeTotalM3: 11,
    viagens: [
        { id: "v1_e3", volumeM3: 5, status: "concluida", timestamp: new Date("2024-05-03T09:00:00") },
        { id: "v2_e3", volumeM3: 6, status: "concluida", timestamp: new Date("2024-05-03T11:00:00") },
    ],
  },
];

// ====================================================================
// MOCK DE ORÇAMENTOS (Inalterado)
// ====================================================================

export const mockOrcamentos = [
  {
    id: "o1",
    empresaId: "1",
    cliente: "Cliente A",
    status: "pendente",
    dataCriacao: new Date("2024-05-10"),
  },
  {
    id: "o2",
    empresaId: "1",
    cliente: "Cliente B",
    status: "aprovado",
    dataCriacao: new Date("2024-05-11"),
  },
];

// ====================================================================
// MOCK DE AGENDAMENTOS (Atualizado com Vendedor e Referência de Entrega)
// ====================================================================

export const mockAgendamentos: Agendamento[] = [
  {
    id: "a1",
    empresaId: "1",
    cliente: "Cliente C",
    data: new Date("2025-10-20T10:00:00"), // Data Futura para agendamento
    descricao: "Reunião de negócios",
    vendedorId: "u2", // Vendedor User
    entregaId: null, // Ainda não virou entrega
  },
  {
    id: "a2",
    empresaId: "1",
    cliente: "Cliente D",
    data: new Date("2024-05-01T13:00:00"),
    descricao: "Entrega urgente de concreto",
    vendedorId: "u2",
    entregaId: "e1", // Ligado à entrega e1
  },
  {
    id: "a3",
    empresaId: "1",
    cliente: "Cliente E",
    data: new Date("2024-05-02T14:30:00"),
    descricao: "Entrega de Cimento",
    vendedorId: "u2",
    entregaId: "e2", // Ligado à entrega e2
  },
  {
    id: "a4",
    empresaId: "1",
    cliente: "Cliente F",
    data: new Date("2024-05-03T09:00:00"),
    descricao: "Entrega de Areia e Brita",
    vendedorId: "u5",
    entregaId: "e3", // Ligado à entrega e3
  },
];

// ====================================================================
// MOCK DE OBRAS (Inalterado)
// ====================================================================

export const mockObras: Obra[] = [
  {
    id: "obra1",
    empresaId: "1",
    nome: "Construção do Shopping",
    localizacao: "Avenida Central, 123",
    status: "Em andamento",
  },
  {
    id: "obra2",
    empresaId: "1",
    nome: "Reforma da Praça",
    localizacao: "Praça da Liberdade",
    status: "Finalizada",
  },
];

// ====================================================================
// MOCK DE PRODUTOS (Inalterado)
// ====================================================================

export const mockProducts: Product[] = [
  { id: "prod1", name: "Gasolina Comum", preco: 5.5, empresaId: "1" },
  { id: "prod2", name: "Etanol", preco: 3.8, empresaId: "1" },
  { id: "prod3", name: "Diesel S10", preco: 4.9, empresaId: "1" },
  { id: "prod4", name: "Óleo Motor", preco: 25.0, empresaId: "1" },
];

// ====================================================================
// MOCK DE MOVIMENTOS FINANCEIROS (Inalterado)
// ====================================================================

export const mockFinanceiroMovimentos: FinanceiroMovimento[] = [
  {
    id: "fm1",
    empresaId: "1",
    type: "receita",
    value: 500.0,
    description: "Venda de cimento",
    date: new Date("2024-05-15"),
  },
  {
    id: "fm2",
    empresaId: "1",
    type: "despesa",
    value: 150.0,
    description: "Pagamento de conta de luz",
    date: new Date("2024-05-16"),
  },
  {
    id: "fm3",
    empresaId: "2",
    type: "receita",
    value: 1200.0,
    description: "Venda de areia",
    date: new Date("2024-05-17"),
  },
];

// ====================================================================
// NOVOS MOCKS PARA O FINANCEIRO E CONFIGURAÇÕES
// ====================================================================

export const mockUsinas: Usina[] = [
  { id: "usina1", name: "Concreto Forte Ltda", contact: "333-3333", precoM3: 250.0, empresaId: "1" },
  { id: "usina2", name: "Cimento Rápido S.A.", contact: "444-4444", precoM3: 275.0, empresaId: "1" },
];

export const mockConfiguracoes: ConfiguracoesEmpresa[] = [
  {
    id: "conf1",
    empresaId: "1",
    valorM3RepasseVendedor: 150.0, // Vendedor repassa 150/m3
    taxaMinimaFrete: 80.0, // Taxa mínima de frete para o motorista
    valorM3Frete: 10.0, // 10 por m3 de frete para o motorista
  },
];