// Componente Auxiliar: UserInviteModal
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Send, Smartphone, UserCheck } from 'lucide-react'; // Importei Smartphone

// Tipos de cargo para o formulário
const ROLES = [
    { value: 'admin', label: 'Administrador' },
    { value: 'vendedor', label: 'Vendedor' },
    { value: 'motorista', label: 'Motorista/Bombista' },
];

interface UserInviteModalProps {
    onClose: () => void;
}

const UserInviteModal: React.FC<UserInviteModalProps> = ({ onClose }) => {
    const [name, setName] = useState('');
    const [phone, setPhone] = useState(''); // Alterado de 'email' para 'phone'
    const [role, setRole] = useState('vendedor');

    const handleInvite = (e: React.FormEvent) => {
        e.preventDefault();
        
        // CORREÇÃO: Verifica o campo 'phone'
        if (!name || !phone || !role) {
            alert('Por favor, preencha todos os campos.');
            return;
        }

        // 1. GERAÇÃO DO LINK DE CADASTRO ÚNICO (Simulado)
        const token = Math.random().toString(36).substring(2, 10);
        const signupUrl = `https://app.concreto-plus.com.br/ativar-conta?token=${token}`; // O link de cadastro real

        // 2. FORMATAÇÃO DA MENSAGEM E DO LINK DO WHATSAPP
        const cleanPhone = phone.replace(/\D/g, ''); // Remove caracteres não numéricos
        const message = encodeURIComponent(`Olá ${name}! Você foi convidado(a) para a plataforma Concreto Plus como ${role}. Clique no link abaixo para criar sua conta: \n\n${signupUrl}`);
        
        // Link que abre o WhatsApp no celular ou web, pré-preenchido
        const whatsappLink = `whatsapp://send?phone=55${cleanPhone}&text=${message}`;
        
        console.log(`Convite pronto para ser enviado via WhatsApp para: ${name} (${phone}) como ${role}`);
        console.log(`Link do WhatsApp gerado (Para usar no navegador do ADMIN): ${whatsappLink}`);
        
        // Em um ambiente real, você faria um pop-up aqui ou usaria a biblioteca de QR Code/API de terceiros.
        
        alert(`Convite gerado para ${name}! O sistema SIMULOU o envio. No ambiente de produção, o WhatsApp abriria automaticamente. O link gerado para teste está no console.`);

        // ABRE O WHATSAPP NO NAVEGADOR DO ADMINISTRADOR (Se estiver em uma ação de clique direta)
        window.open(whatsappLink, '_blank');
        
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-md">
                <CardHeader>
                    <CardTitle className="flex items-center"><Send className="h-5 w-5 mr-2" /> Convidar Novo Usuário</CardTitle>
                    <CardDescription>
                        Preencha os dados e o link de convite será gerado para envio direto via WhatsApp.
                    </CardDescription>
                </CardHeader>
                <form onSubmit={handleInvite}>
                    <CardContent className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="name">Nome Completo</Label>
                            <Input 
                                id="name" 
                                placeholder="João da Silva" 
                                value={name} 
                                onChange={(e) => setName(e.target.value)} 
                                required
                            />
                        </div>
                        <div className="space-y-2">
                            {/* CAMPO ALTERADO: Telefone em vez de Email */}
                            <Label htmlFor="phone" className="flex items-center"><Smartphone className="h-4 w-4 mr-1"/> WhatsApp (DDD + Número)</Label>
                            <Input 
                                id="phone" 
                                type="tel" // Tipo 'tel' para melhor suporte em mobile
                                placeholder="5511987654321" // Formato com 55 (DDI)
                                value={phone} 
                                onChange={(e) => setPhone(e.target.value)} 
                                required
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="role">Cargo</Label>
                            <select 
                                id="role" 
                                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                value={role} 
                                onChange={(e) => setRole(e.target.value)}
                                required
                            >
                                {ROLES.map(r => (
                                    <option key={r.value} value={r.value}>{r.label}</option>
                                ))}
                            </select>
                        </div>
                    </CardContent>
                    <CardFooter className="justify-end space-x-2">
                        <Button variant="outline" type="button" onClick={onClose}>Cancelar</Button>
                        <Button type="submit">
                            <Send className="h-4 w-4 mr-2" /> Gerar Link WhatsApp
                        </Button>
                    </CardFooter>
                </form>
            </Card>
        </div>
    );
};